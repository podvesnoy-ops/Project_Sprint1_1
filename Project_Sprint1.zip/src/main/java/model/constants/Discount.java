package model.constants;

public class Discount {
    public static final double DISCOUNT_FOR_RED_APPLE = 60.0;
}
